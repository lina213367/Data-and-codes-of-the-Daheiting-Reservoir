getwd()
setwd('E:/Data and Code/Stratification period')
data <- read.csv("E:/Data and Code/Data/Data of stratification period.csv",header = TRUE)
head(data)


set.seed(3)                        
split <- sample(c(TRUE, FALSE), nrow(data), replace = TRUE, prob = c(0.8, 0.2))
c <- which(split)
train <- data[c,]
train_X <- train[,2:16]
train_Y <- train[,18]
train_Y1 <- data.frame(train_Y)
test <- data[-c,]
test_X <- test[,2:16]
test_Y <- test[,18]
test_Y1 <- data.frame(test_Y)
data_X <- data[,2:16]
data_Y <- data[,18]
data_Y1 <- data.frame(data_Y)


library(dismo)
library(gbm)

fit_Chla <- gbm.step(data=train,gbm.x = 2:16,gbm.y=18,family = "gaussian",tree.complexity = 5,
             learning.rate = 0.01,bag.fraction = 0.5,n.folds=10) 
fit_Chla$gbm.call$best.trees
summary(fit_Chla)


predictions_train <- predict(fit_Chla, newdata = train_X, n.trees = fit_Chla$gbm.call$best.trees)
predictions_train1 <- data.frame(predictions_train)


train_rmse <- sqrt(mean((predictions_train - train_Y)^2))
train_r2 <- cor(predictions_train, train_Y)^2
cat("RMSE:", train_rmse, "\n")
cat("R2:", train_r2, "\n")


predictions_test <- predict(fit_Chla, newdata = test_X, n.trees = fit_Chla$gbm.call$best.trees)
predictions_test1 <- data.frame(predictions_test)


test_rmse <- sqrt(mean((predictions_test - test_Y)^2))
test_r2 <- cor(predictions_test, test_Y)^2
cat("RMSE:", test_rmse, "\n")
cat("R2:", test_r2, "\n")


predictions_all <- predict(fit_Chla, newdata = data_X, n.trees = fit_Chla$gbm.call$best.trees)
predictions_all1 <- data.frame(predictions_all)


all_rmse <- sqrt(mean((predictions_all - data_Y)^2))
all_r2 <- cor(predictions_all, data_Y)^2
cat("RMSE:", all_rmse, "\n")
cat("R2:", all_r2, "\n")


windowsFonts(Times_New_Roman=windowsFont("Times New Roman"))
par(family='Times_New_Roman')

par(pin = c(11.26, 4.72))  
par(mfrow = c(2, 3))  
par(mar = c(4, 4, 2, 1))  
par(oma = c(1, 1, 0.5, 0.5))  
gbm.plot(fit_Chla, variable.no = 0, smooth = TRUE, rug = FALSE, 
         n.plots = 6, common.scale = TRUE, 
         write.title = FALSE, y.label = "fitted function", x.label = NULL, 
         show.contrib = FALSE, plot.layout = c(2, 3), cex.lab = 1.8, cex.axis = 1.4)
gbm.plot.fits(fit_Chla, v = 0, mask.presence = FALSE, use.factor = FALSE)
par(family='Times_New_Roman')



