getwd()
setwd('E:/Data and Code/Stratification period')
data <- read.csv("E:/Data and Code/Data/Data of stratification period.csv",header = TRUE)
head(data)

set.seed(5)                        
split <- sample(c(TRUE, FALSE), nrow(data), replace = TRUE, prob = c(1.0, 0.0))
c <- which(split)
train <- data[c,]
test <- data[-c,]
test_Y <- test[,17]
test_Y1 <- data.frame(test_Y)
test_Y1

library(dismo)
library(gbm)
fit_MI <- gbm.step(data=train,gbm.x = 2:17,gbm.y=19,family = "gaussian",tree.complexity = 5,
             learning.rate = 0.01,bag.fraction = 0.5,n.folds=10) 
fit_MI$gbm.call$best.trees
summary(fit_MI)

windowsFonts(Times_New_Roman=windowsFont("Times New Roman"))
par(family='Times_New_Roman')
par(pin = c(11.26, 4.72))  
par(mfrow = c(2, 3))  
par(mar = c(4, 4, 2, 1))  
par(oma = c(1, 1, 0.5, 0.5))  
gbm.plot(fit_MI, variable.no = 0, smooth = TRUE, rug = FALSE, 
         n.plots = 6, common.scale = TRUE, 
         write.title = FALSE, y.label = "fitted function", x.label = NULL, 
         show.contrib = FALSE, plot.layout = c(2, 3), cex.lab = 1.8, cex.axis = 1.4)
par(family='Times_New_Roman')
